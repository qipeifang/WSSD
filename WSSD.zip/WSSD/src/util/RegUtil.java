package util;

import java.io.IOException;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import bean.DBO;
import bean.UserLoginBean;

public class RegUtil extends HttpServlet {
	
	
	public static Statement stmt =DBO.createStmt(DBO.getConn()); //��ѯ

	public final static String CONTENTTYPE="text/html;charset=gb2312";
	public final static String CHARACTERENCODING="gb2312";
	
	public RegUtil() {
		super();
	}

	
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		
		

		request.setCharacterEncoding(this.CHARACTERENCODING);
		response.setContentType(this.CONTENTTYPE);
		String method=request.getParameter("method").trim();
		UserLoginBean ub=new UserLoginBean();
		if(method.equals("reg")){
			String login=request.getParameter("login").trim();
			String password=request.getParameter("password").trim();
			String name=request.getParameter("name").trim();
			String sex=request.getParameter("sex").trim();
			String email=request.getParameter("email").trim();
			String tel=request.getParameter("tel").trim();
			if(login.equals("")||password.equals("")||name.equals("")||email.equals("")||tel.equals("")){
				request.setAttribute("login", login);
				request.setAttribute("password", password);
				request.setAttribute("name", name);
				request.setAttribute("email", email);
				request.setAttribute("tel", tel);
				request.setAttribute("message", "������д������Ŀ��");
				request.getRequestDispatcher("reg.jsp").forward(request, response);
			}
			else{
				
				if(login.length()>0 && password.length()==6 && name.length()>0&&sex.length()>0&&email.length()>0&&tel.length()>0){
					try {
						stmt.executeUpdate("insert into commonmember(member_loginname,member_password,member_truename,member_sex,member_email,member_tel,member_level) values('"+login+"','"+password+"','"+name+"','"+sex+"','"+email+"','"+tel+"','0')");
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					String url= request.getParameter("url");
					HttpSession session=request.getSession();
					session.setAttribute("name", login);
					request.setAttribute("message", "ע��ɹ���");
					request.getRequestDispatcher("center.jsp").forward(request, response);
				}else{
					request.setAttribute("message", "ע��ʧ�ܣ�");
					request.getRequestDispatcher("reg.jsp").forward(request, response);
				}
			}
			
		}
		else if(method.equals("lost")){
			String login=request.getParameter("login").trim();
			String email=request.getParameter("email").trim();
			int i=ub.getMiMa(login, email);
			if(i==1){
				request.setAttribute("message", "����ɹ��һأ�����������Ϊ123456�����½�󾡿��޸ģ�");
				request.getRequestDispatcher("index.jsp").forward(request, response);
			}
			else if(i==3){
				request.setAttribute("message", "��½�����������");
				request.getRequestDispatcher("lost.jsp").forward(request, response);
			}
			else if(i==2){
				request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
				request.getRequestDispatcher("lost.jsp").forward(request, response);
			}
		}
		else if(method.equals("up")){
			String login=request.getParameter("login").trim();
			String password=request.getParameter("password").trim();
			String name=request.getParameter("name").trim();
			String sex=request.getParameter("sex").trim();
			String email=request.getParameter("email").trim();
			String tel=request.getParameter("tel").trim();
			if(login.equals("")||password.equals("")||name.equals("")||email.equals("")||tel.equals("")){
				request.setAttribute("login", login);
				request.setAttribute("password", password);
				request.setAttribute("name", name);
				request.setAttribute("email", email);
				request.setAttribute("tel", tel);
				request.setAttribute("message", "������д������Ŀ��");
				request.getRequestDispatcher("upuser.jsp").forward(request, response);
			}
			else{
				try{
					int t=Integer.parseInt(tel);
					int i=ub.upUser(login, password, name, sex, email, tel);
					if(i==1){
						request.setAttribute("message", "�����ɹ���");
						request.getRequestDispatcher("upuser.jsp").forward(request, response);
					}
					else{
						request.setAttribute("login", login);
						request.setAttribute("password", password);
						request.setAttribute("name", name);
						request.setAttribute("email", email);
						request.setAttribute("tel", tel);
						request.setAttribute("message", "ϵͳά���У����Ժ����ԣ�");
						request.getRequestDispatcher("upuser.jsp").forward(request, response);
					}
				}catch(Exception e){
					request.setAttribute("login", login);
					request.setAttribute("password", password);
					request.setAttribute("name", name);
					request.setAttribute("email", email);
					request.setAttribute("tel", tel);
					request.setAttribute("message", "�绰����ֻ��Ϊ���֣�");
					request.getRequestDispatcher("upuser.jsp").forward(request, response);
				}		
			}
		}
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occure
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
