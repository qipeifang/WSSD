package bean;
public class SmartUploadException extends Exception
{

    SmartUploadException(String s)
    {
        super(s);
    }
}
